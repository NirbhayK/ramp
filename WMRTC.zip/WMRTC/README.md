<h1 align="center">Welcome to WMRTC-Signalling-Server 👋</h1>
<p>
  <img alt="Version" src="https://img.shields.io/badge/version-1.0-blue.svg?cacheSeconds=2592000" />
  <a href="#" target="_blank">
    <img alt="License: MIT" src="https://img.shields.io/badge/License-MIT-yellow.svg" />
  </a>
</p>

> Powering RAMP platform - Stage - `prototype`

### 🏠 [Homepage](https://www.wellbeingtech.com/)

### ✨ [Demo](https://eyes.thewarriormonk.app/)

## Install

```sh
git clone https:/<repo_url>/wmrtc
npm install
node server.js
```

## Usage
http://localhost:3000

## Run tests

## Author

👤 **Roman Savchuk**